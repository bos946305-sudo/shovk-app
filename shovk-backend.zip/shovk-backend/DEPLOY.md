# Запуск сервера в интернете (VPS + HTTPS)

Без публичного адреса с HTTPS Monobank не пришлёт подтверждение оплаты, склад не пришлёт данные, а ссылки на товары не откроют приложение. Ниже путь на обычном VPS с Docker. Займёт 30–60 минут.

## 1. Что купить

1. VPS с Ubuntu 22.04 или 24.04, 1–2 ГБ памяти (подойдёт любой хостинг: Hetzner, DigitalOcean, Contabo, украинские провайдеры).
2. Домен, например `shovk.ua`. Для сервера создайте поддомен `api.shovk.ua`: в DNS добавьте запись A, указывающую на IP вашего VPS.

## 2. Подготовка сервера

```bash
ssh root@IP_СЕРВЕРА
curl -fsSL https://get.docker.com | sh
ufw allow 22 && ufw allow 80 && ufw allow 443 && ufw --force enable
```

## 3. Загрузка проекта

Распакуйте `shovk-backend.zip` у себя и скопируйте папку на сервер: `scp -r shovk-backend root@IP_СЕРВЕРА:/opt/shovk`. Дальше на сервере:

```bash
cd /opt/shovk
cp .env.example .env
python3 gen_secrets.py        # покажет случайные секреты: перенесите их в .env вместо пустых
nano .env
```

Что заполнить в `.env`:

| Переменная | Значение |
| --- | --- |
| `DOMAIN` | `api.shovk.ua` (без https://) |
| `PUBLIC_URL` | `https://api.shovk.ua` |
| `JWT_SECRET`, `ADMIN_TOKEN`, `APP_TOKEN`, `WEBHOOK_SECRET_MEEST` | значения из gen_secrets.py |
| `MONOBANK_TOKEN` | токен эквайринга из кабинета Monobank (ваш, не мой) |
| `RAPIDAPI_KEY`, `RAPID_TAOBAO_*` и т. д. | из вкладки Code Snippets на RapidAPI |
| `RAPID_IMGSEARCH_*` | API поиска по фото, который вы подключили на RapidAPI |
| `FCM_PROJECT_ID`, `FCM_CREDENTIALS_FILE=/secrets/firebase.json` | из Firebase; сам JSON положите в папку `secrets/` |

## 4. Запуск

```bash
docker compose up -d --build
curl https://api.shovk.ua/health        # должно вернуть {"ok":true,...}
docker compose logs -f api              # журнал сервера
```

Сертификат HTTPS Caddy получит сам при первом обращении (DNS должен уже указывать на сервер).

## 5. Адреса, которые нужны другим

| Кому | Адрес |
| --- | --- |
| Monobank | прописывать не нужно: сервер сам передаёт `https://api.shovk.ua/webhooks/monobank` при создании счёта |
| LiqPay (если используете) | `https://api.shovk.ua/webhooks/liqpay` указывается автоматически в каждом платеже |
| Склад (Meest China) | `https://api.shovk.ua/webhooks/logistics/meest`, заголовок `X-Webhook-Secret` со значением `WEBHOOK_SECRET_MEEST`. Формат тела: см. README, раздел 9 |
| Приложение | `API_BASE=https://api.shovk.ua`, `PUBLIC_HOST=api.shovk.ua`, `APP_TOKEN` такой же, как в `.env` |

## 6. Обновление и копии

Обновление: загрузите новые файлы и выполните `docker compose up -d --build`. Данные заказов лежат в томе `shovk-data`: настройте ежедневную копию (например, `docker run --rm -v shovk_shovk-data:/d -v /root/backup:/b alpine tar czf /b/shovk-$(date +%F).tgz /d`) и храните её вне этого сервера.
