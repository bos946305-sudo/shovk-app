"""Печатает случайные секреты для .env. Запуск: python3 gen_secrets.py
Значения копируйте в .env вручную, вместо пустых. В чат и мессенджеры их не отправляйте."""
import secrets

for name in ("JWT_SECRET", "ADMIN_TOKEN", "APP_TOKEN", "WEBHOOK_SECRET_MEEST", "WEBHOOK_SECRET_GENERIC"):
    print(f"{name}={secrets.token_urlsafe(32)}")
